# 💰 Mis Gastos — Guía de instalación

## Paso 1 — Descargar Node.js
Si no lo tienes instalado:
👉 https://nodejs.org → descargar versión LTS

---

## Paso 2 — Crear repo en GitHub
1. Ve a https://github.com y entra a tu cuenta
2. Clic en **"New"** (botón verde)
3. Nombre del repo: `mis-gastos`
4. Dejarlo en **Public**
5. NO marcar ningún checkbox extra
6. Clic en **"Create repository"**

---

## Paso 3 — Subir los archivos al repo
En la página del repo recién creado:
1. Clic en **"uploading an existing file"**
2. Arrastra TODOS los archivos de esta carpeta (respetando la estructura)
3. Clic en **"Commit changes"**

> ⚠️ Importante: la carpeta `src` debe quedar dentro del repo con sus archivos adentro.

---

## Paso 4 — Conectar a Vercel
1. Ve a https://vercel.com e inicia sesión con tu cuenta de GitHub
2. Clic en **"Add New Project"**
3. Busca el repo `mis-gastos` y clic en **"Import"**
4. Vercel detecta Vite automáticamente — no cambies nada
5. Clic en **"Deploy"**
6. En ~1 minuto tendrás una URL tipo `mis-gastos.vercel.app`

---

## Paso 5 — Instalar en el iPhone como app
1. Abre Safari en tu iPhone
2. Entra a la URL de Vercel (ej: `mis-gastos.vercel.app`)
3. Toca el ícono de **Compartir** (cuadrado con flecha ↑)
4. Desplázate y toca **"Agregar a pantalla de inicio"**
5. Escribe el nombre: **Mis Gastos**
6. Toca **Agregar**

¡Listo! Ya tienes el ícono en tu iPhone como si fuera una app nativa.

---

## Notas
- Los datos se guardan en el teléfono (localStorage), no en la nube
- Funciona sin internet una vez instalada
- Es independiente de ColeKtoR — cada app tiene su propio repo y URL
